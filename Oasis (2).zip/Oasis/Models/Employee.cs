﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oasis.Models
{
    class Employee
    {
        public string First;
        public string Last;
        public int Id;
        public bool IsManager;
    }
}
