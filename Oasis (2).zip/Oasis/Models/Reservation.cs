﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oasis.Models
{
    class Reservation
    {
        public bool IsActive;
        public bool IsCharged;
        public int PenaltyAmount;
        public int RoomNumber;
        public string Name;
        public string Email;
        public DateTime Start;
        public DateTime End;
        public DateTime CheckIn;
        public BaseRate[] BaseRates;
        public CreditCard CreditCard;

        // override for different reservation multipliers
        public virtual int Multiplier() { return 1; }

        public bool Matches(string name, string email, string cardNumber)
        {
            return (this.Name.Equals(name) || this.Email.Equals(email) || this.CreditCard.Number.Equals(cardNumber));
        }

        public override string ToString()
        {
            return string.Format("Name: {0}, Start: {1}, End: {2}", Name, Start.ToShortDateString(), End.ToShortDateString());
        }
    }
}
