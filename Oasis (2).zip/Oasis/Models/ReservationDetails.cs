﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oasis.Models
{
    class ReservationDetails
    {
        public string Name;
        public string Email;
        public DateTime Start;
        public DateTime End;
    }
}
