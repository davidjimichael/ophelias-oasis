﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oasis.BusinessLogic;
using Oasis.Models;

namespace Oasis
{
    class Program
    {
        static void Main(string[] args)
        {
            var res = new Reservation
            {
                Start = DateTime.Now,
                End = DateTime.Now.AddDays(4),
                Name = "David Michael",
            };

            var res1 = new Reservation
            {
                Start = DateTime.Now.AddDays(3),
                End = DateTime.Now.AddDays(6),
                Name = "Derek Jeter",
            };

            var roomScheduler = new RoomScheduler(roomCount: 45);

            roomScheduler.InsertReservation(res);
            roomScheduler.InsertReservation(res1);

            for (int i = 0; i < 6; i++)
            {
                var x = roomScheduler.GetCheckedInReservations(DateTime.Now.AddDays(i));

                foreach (string s in x.Select((r, j) => "Room " + j + ": " + r?.ToString() + "\n"))
                {
                    Console.Write(s);
                }
            }
            Console.ReadKey();
        }
    }
}
